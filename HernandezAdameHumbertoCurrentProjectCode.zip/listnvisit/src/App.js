import "./App.css";
import GoogleLogin from "react-google-login";
import { Outlet, Link } from "react-router-dom";

//const clientID ="349688757491-75nt1j8mns1n2mr3dh9crtvsuqh9nvh9.apps.googleusercontent.com";
//const clientSecret = "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";

//want to add Redux, will most likely have to redo this part
function App() {
  const responseGoogle = (response) => {
    console.log(response);
  };

  return (
    <div className="App">
      {/*Google component for login */}
      <GoogleLogin
        clientId="349688757491-75nt1j8mns1n2mr3dh9crtvsuqh9nvh9.apps.googleusercontent.com"
        buttonText="Login with Google"
        onSuccess={responseGoogle}
        onFailure={responseGoogle}
        cookiePolicy="single_host_origin"
      />
    </div>
  );
}

export default App;
